<?php

$conn = mysqli_connect('localhost','root','','hello') or die('connection failed');

?>