
<section class="footer">
      <div class="credit"><h1>Contact info</h1>

           <div class="box-container">

                 <p ><b>Address:<br>Roadcess Chowk,Biratnagar<br>Morang,Nepal</b>
                 </p>
                <p><b>Phone 1:<br>9812345625</b></p>
                <p><b>Phone 2:<br>9842123497</b></p>
                 
                 <p><b>Email:<br>www.online furniture store.com</b></p>
           </div>


       </div>
     

    <div class="credit">&copy; copyright @ <?php echo date('Y'); ?> by <span><a href="home.php" class="logo">FURNITURE STORE.</a>All rights reserved.</span> </div>

</section>